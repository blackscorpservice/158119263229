var _constants = {

};
_constants.SWIPE = {

}

